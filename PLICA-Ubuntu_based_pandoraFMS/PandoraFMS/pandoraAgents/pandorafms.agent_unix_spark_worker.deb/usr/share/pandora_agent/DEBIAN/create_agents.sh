#!/bin/bash

echo Iniciando creacion de agentes Pandora FMS

bash make_deb_package_kafka.sh
bash make_deb_package_zookeeper.sh
bash make_deb_package_spark_master.sh
bash make_deb_package_spark_worker.sh
bash make_deb_package_correlacion.sh
bash make_deb_package_ontologia.sh

echo Teminada la creacion de agentes Pandora FMS
